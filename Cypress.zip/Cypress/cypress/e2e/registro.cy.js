describe('Registro de usuario en ParaBank', () => {

  it('Debe completar todos los campos requeridos y registrar un nuevo usuario', () => {
    cy.visit('https://parabank.parasoft.com/parabank/register.htm')
    cy.get('#customer\\.firstName').type('Laura')
    cy.get('#customer\\.lastName').type('Calvo')
    cy.get('#customer\\.address\\.street').type('Cl 10 #67 34')
    cy.get('#customer\\.address\\.city').type('Bogotá')
    cy.get('#customer\\.address\\.state').type('Cundinamarca')
    cy.get('#customer\\.address\\.zipCode').type('110111')
    cy.get('#customer\\.phoneNumber').type('3502351110')
    cy.get('#customer\\.ssn').type('123456789')
    cy.get('#customer\\.username').type('lauracalvogg')
    cy.get('#customer\\.password').type('Prueba2025')
    cy.get('#repeatedPassword').type('Prueba2025')
    cy.get('input[value="Register"]').click()
    cy.contains('Welcome').should('be.visible')
  })
})
