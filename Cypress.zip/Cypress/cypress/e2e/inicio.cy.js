describe('Inicio de sesión', () => {
  it('Debe iniciar sesión correctamente', () => {
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    cy.get('input[name="username"]').type('lauracalvogg')
    cy.get('input[name="password"]').type('Prueba2025')
    cy.get('input[value="Log In"]').click()
    cy.contains('Accounts Overview').should('be.visible')
  })
})
