  it('Debe mostrar mensaje de error por credenciales inválidas', () => {
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    cy.get('input[name="username"]').type('lauracalvogg')
    cy.get('input[name="password"]').type('ClaveErronea')
    cy.get('input[value="Log In"]').click()
    cy.contains('The username and password could not be verified.').should('be.visible')
  })

