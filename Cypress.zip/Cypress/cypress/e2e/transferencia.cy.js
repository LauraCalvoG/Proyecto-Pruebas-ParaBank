describe('Transferencia entre cuentas', () => {
  it('Debe realizar transferencia correctamente', () => {
    cy.login('lauracalvogg', 'Prueba2025')
    cy.contains('Transfer Funds').click()
    cy.get('#fromAccountId', { timeout: 10000 }).should('exist').and('be.visible')
    cy.get('#toAccountId', { timeout: 10000 }).should('exist').and('be.visible')
    cy.get('#fromAccountId option').should('contain', '21780')
    cy.get('#toAccountId option').should('contain', '22557')
    cy.get('#amount').clear().type('100')
    cy.get('#fromAccountId').select('21780')
    cy.get('#toAccountId').select('22557')
    cy.get('input[value="Transfer"]').click()
    cy.contains('Transfer Complete!').should('be.visible')
    cy.screenshot('Transferencia_Exitosa')
  })
})

