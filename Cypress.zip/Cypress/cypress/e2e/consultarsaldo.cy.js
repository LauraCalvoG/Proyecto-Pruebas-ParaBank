describe('Consulta de saldo', () => {
  it('Debe mostrar saldos disponibles', () => {
    cy.login('lauracalvogg', 'Prueba2025')
    cy.contains('Accounts Overview').should('be.visible')
    cy.get('table').should('contain', 'Balance')
  })
})
