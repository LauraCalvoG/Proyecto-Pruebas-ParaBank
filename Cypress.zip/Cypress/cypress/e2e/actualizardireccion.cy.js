describe('Actualizar dirección con datos inválidos en ParaBank', () => {
  it('Debe intentar actualizar dirección con campos vacíos o inválidos', () => {

    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    cy.get('input[name="username"]').type('lauracalvogg')
    cy.get('input[name="password"]').type('Prueba2025')
    cy.get('input[value="Log In"]').click()

    cy.contains('Update Contact Info').click()
    cy.url().should('include', '/updateprofile.htm')
    cy.get('#customer\\.address\\.zipCode').clear()
    cy.get('input[value="Update Profile"]').click()
    cy.contains('Profile Updated').should('be.visible')
  })
})
