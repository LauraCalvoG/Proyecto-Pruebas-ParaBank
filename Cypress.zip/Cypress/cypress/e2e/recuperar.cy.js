describe('Recuperar o cambiar contraseña en ParaBank', () => {
  it('Debe permitir recuperar información de login con los datos personales correctos', () => {
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    cy.contains('Forgot login info?').click()
    cy.url().should('include', '/lookup.htm')
    cy.contains('Customer Lookup').should('be.visible')

    cy.get('input[id="firstName"]').type('Laura')
    cy.get('input[id="lastName"]').type('Calvo')
    cy.get('input[id="address.street"]').type('C10 #67 34')
    cy.get('input[id="address.city"]').type('Bogotá')
    cy.get('input[id="address.state"]').type('Cundinamarca')
    cy.get('input[id="address.zipCode"]').type('110111')
    cy.get('input[id="ssn"]').type('123456789')

    cy.get('input[value="Find My Login Info"]').click()

    cy.contains('Your login information was located successfully', { timeout: 10000 })
      .should('be.visible')
  })
})
