describe('Transferencia de fondos entre cuentas en ParaBank', () => {
  it('Debe mostrar error al transferir más dinero del disponible', () => {
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    cy.get('input[name="username"]').type('lauracalvogg')
    cy.get('input[name="password"]').type('Prueba2025')
    cy.get('input[value="Log In"]').click()
    cy.contains('Transfer Funds').click()
    cy.url().should('include', '/transfer.htm')
    cy.get('#amount').type('10000')
    cy.get('#fromAccountId').select('14454') 
    cy.get('input[value="Transfer"]').click()
    cy.contains('Insufficient Funds').should('be.visible')
  })
})
