describe('Solicitar préstamo', () => {
  it('Debe procesar la solicitud de préstamo correctamente', () => {
    cy.login('lauracalvogg', 'Prueba2025')
    cy.contains('Request Loan').click()
    cy.get('#amount').type('5000')
    cy.get('#downPayment').type('1000')
    cy.get('#fromAccountId').select(0)
    cy.get('input[value="Apply Now"]').click()
    cy.contains('Loan Request Processed').should('be.visible')
  })
})
