describe('Apertura de cuenta', () => {
  it('Debe crear nueva cuenta', () => {
    cy.login('lauracalvogg', 'Prueba2025')
    cy.contains('Open New Account').click()
    cy.get('#type').select('CHECKING')
    cy.get('#fromAccountId').select(0)
    cy.get('input[value="Open New Account"]').click()
    cy.contains('Account Opened!').should('be.visible')
  })
})
