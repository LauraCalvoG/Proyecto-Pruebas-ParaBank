describe('Solicitud de préstamo sin datos', () => {
  it('Debe mostrar advertencias por campos vacíos', () => {
    cy.login('lauracalvog', 'Prueba2025')
    cy.contains('Request Loan').click()
    cy.get('#amount').clear()
    cy.get('#downPayment').clear()
    cy.get('input[value="Apply Now"]').click()
    cy.contains('This field is required.').should('be.visible')
  })
})
S