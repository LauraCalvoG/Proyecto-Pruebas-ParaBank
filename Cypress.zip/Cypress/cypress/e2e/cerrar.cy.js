describe('Cerrar sesión', () => {
  it('Debe cerrar sesión correctamente', () => {
    cy.login('lauracalvogg', 'Prueba2025')
    cy.contains('Log Out').click()
    cy.url().should('include', 'index.htm')
  })
})
