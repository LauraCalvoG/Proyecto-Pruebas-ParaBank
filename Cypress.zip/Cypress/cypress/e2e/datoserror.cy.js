describe('Registro con campos vacíos', () => {
  it('Debe mostrar errores al dejar campos sin llenar', () => {
    cy.visit('https://parabank.parasoft.com/parabank/register.htm')
    cy.get('#customer\\.firstName').clear()
    cy.get('#customer\\.lastName').type('Calvo')
    cy.get('#customer\\.username').clear()
    cy.get('#customer\\.password').type('Prueba2025')
    cy.get('#repeatedPassword').type('Prueba2025')
    cy.get('input[value="Register"]').click()
    cy.contains('This field is required.').should('be.visible')
  })
})
