describe('Buscar transacción por fecha en ParaBank', () => {
  it('Debe permitir encontrar una transacción usando la fecha 28/10/2025', () => {

    // 1️⃣ Iniciar sesión
    cy.visit('https://parabank.parasoft.com/parabank/index.htm')
    cy.get('input[name="username"]').type('lauracalvogomez')
    cy.get('input[name="password"]').type('Prueba2025')
    cy.get('input[value="Log In"]').click()

    // 2️⃣ Ir a Find Transactions
    cy.contains('Find Transactions').click()
    cy.url().should('include', '/findtrans.htm')

    // 3️⃣ Seleccionar cuenta
    cy.get('select[id="accountId"]').select('15453')

    // 4️⃣ Escribir la fecha (MM-DD-YYYY)
    cy.get('input[id="transactionDate"]').clear().type('10-28-2025')

    // 5️⃣ Clic en el botón dentro del formulario correcto
    cy.get('input[id="transactionDate"]')
      .parents('form')
      .within(() => {
        cy.get('input[type="Submit"]').click()
      })

    // 6️⃣ Validar resultados
    cy.contains('Transactions for Account').should('be.visible')
  })
})


